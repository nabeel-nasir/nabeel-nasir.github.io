#include <iostream>

int main(){
    std::cout << "Welcome to the Choose-Your Own Adventure Project" << std::endl;
    //The game should be created using iostream as it is a text-based choose-your-own-adventure
    //If you want to do it differently, please let a TA or ULA know before you committ to a different idea
    return 0;
}