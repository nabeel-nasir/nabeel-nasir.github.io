int partition(int arr[], int low, int high);
void quickSort(int arr[], int low, int high);