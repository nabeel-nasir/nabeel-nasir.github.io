#include "func.h"
#define MYCONST 5

int glob_var = 15;

int main() {
    int x = MYCONST, y = 10;
    char* str = "some text";
    swap(&x, &y);
    return 0;
}